#include "KNNSim.h"

int main(int argc, char const *argv[]) {
  int numberControl, numberClassify, numberFeatures, numberClasses, numberNeighbors;
  Dataset *dataset;
  struct timeval startTime, endTime;

  // optional arguments
  RunType runType   = plain;                      // type of run
  int     inputFile = 0;     char *inputFilename; // optional binary input file

  // checking for right number of arguments
  assert(argc >= 6);

  // parsing arguments
  numberControl   = atoi(argv[1]);
  numberClassify  = atoi(argv[2]);
  numberFeatures  = atoi(argv[3]);
  numberClasses   = atoi(argv[4]);
  numberNeighbors = atoi(argv[5]);

  for (int i = 6; i < argc - 1; i += 2) {
    // specified type of run
    if (!strcmp(argv[i], "--run-type") || !strcmp(argv[i], "-r")) {
      if     (!strcmp(argv[i + 1], "plain"      )) runType = plain;
      else if(!strcmp(argv[i + 1], "multithread")) runType = multithread;
    }
    // specified input file
    else if (!strcmp(argv[i], "--input-file") || !strcmp(argv[i], "-f")) {
      inputFile     = 1;
      inputFilename = (char *) argv[i + 1];
    }
    // optional argument not recognized
    else {
      printf("Optional argument %s is invalid and will be ignored\n", argv[i]);
      i--;
    }
  }

  // if an input file is provided, use it; otherwise generate the dataset
  if (inputFile == 1)
    dataset = loadDataset(numberControl, numberClassify, numberFeatures, numberClasses, inputFilename);
  else
    dataset = randDataset(numberControl, numberClassify, numberFeatures, numberClasses);

  // execute knn algorithm
  gettimeofday(&startTime, NULL);
  knnAlgorithm(runType, dataset, numberNeighbors);
  gettimeofday(&endTime, NULL);

  // print summary
  printf(" Type of run: %d\n", runType);
  printf("Time elapsed: %lf seconds\n", getElapsedTime(startTime, endTime));

  //for (size_t i = 0; i < dataset->numberClassify; i++) {
  //  printf("%d\n", dataset->classifyClasses[i]);
  //}

  destroyDataset(dataset);

  return 0;
}

double getElapsedTime(struct timeval startTime, struct timeval endTime) {
  return (endTime.tv_sec - startTime.tv_sec) + (endTime.tv_usec - startTime.tv_usec) / 1000000.00;
}
